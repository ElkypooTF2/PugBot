module.exports.run = (bot, msg, args, config, c_info) => {
        msg.channel.send("**Pong!**");
};