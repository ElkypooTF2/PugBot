DEPENDENCIES (YOU MUST INSTALL THESE IN ORDER TO RUN THIS BOT):
    - node.js [https://nodejs.org/en/]
    - pm2 [http://pm2.keymetrics.io/]

Once you have all of these installed, just run "run.bat".
Enjoy!